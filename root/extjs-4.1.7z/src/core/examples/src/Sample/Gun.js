Ext.define('Sample.Gun', {
    
});